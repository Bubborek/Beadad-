﻿using System;
class Program
{
    static void Main(string[] args)
    {
        int[] szamok = { 1, 2, 3, 4, 5, 6 };
        // Összegzés tétel
        Console.WriteLine("Összegzés tétel:");
        int vegOsszeg = OsszegzesTetel(szamok);
        Console.WriteLine(vegOsszeg);

        // Eldöntés tétel
        Console.WriteLine("Eldöntés tétel: van 69?");
        bool letezikElem = EldontesTetel(szamok, 69);
        Console.WriteLine(letezikElem ? "Igen" : "Nem");
        // Kiválasztás tétel

        Console.WriteLine("Kiválasztás tétel:");
        try
        {
            int valasztottElem = KivalasztasTetel(szamok, 3);
            Console.WriteLine("Az adott elem: " + valasztottElem);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        // Lineáris keresés tétel
        Console.WriteLine("\nLineáris keresés:");
        int elemIndex = LinearisKeresesTetel(szamok, 5);
        if (elemIndex != -1)
        {
            Console.WriteLine($"Az elem indexe: {elemIndex}");
        }
        else
        {
            Console.WriteLine("Az elem nem létezik");
        }
    }
    public static int OsszegzesTetel(int[] tomb)
    {
        int osszeg = 0;
        foreach (var ertek in tomb)
        {
            osszeg += ertek;
        }
        return osszeg;
    }
    public static bool EldontesTetel(int[] tomb, int keresendo)
    {
        foreach (var ertek in tomb)
        {
            if (ertek == keresendo)
            {
                return true;
            }
        }
        return false;
    }
    public static int KivalasztasTetel(int[] tomb, int keresendo)
    {
        foreach (var ertek in tomb)
        {
            if (ertek == keresendo)
            {
                return ertek;
            }
        }
        throw new Exception("Az elem nem létezik!");
    }
    public static int LinearisKeresesTetel(int[] tomb, int keresendo)
    {
        for (int i = 0; i < tomb.Length; i++)
        {
            if (tomb[i] == keresendo)
            {
                return i;
            }
        }
        return -1;
    }
}