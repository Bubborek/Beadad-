﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int[] array = { 1, 2, 3, 4, 5, 6 };
        
        // Összegzés tétel
        Console.WriteLine("Összegzés tétel:");
        int osszeg = Osszegzes(array);
        Console.WriteLine(osszeg);

        // Eldöntés tétel
        Console.WriteLine("Eldöntés tétel: van 4?");
        bool vanElem = Eldontes(array, 4);
        Console.WriteLine(vanElem ? "Igen");
        Console.WriteLine(vanElem ? "Nem");

        // Kiválasztás tétel
        Console.WriteLine("Kiválasztás tétel:");
        try
        {
            int kivElem = Kivalasztas(array, 3);
            Console.WriteLine("Az adott elem: " + kivElem);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }

        // Lineáris keresés tétel
        Console.WriteLine("\nLineáris keresés:");
        int index = LinearisKereses(array, 5);
        if (index != -1)
        {
            Console.WriteLine($"Az elem indexe: {index}");
        }
        else
        {
            Console.WriteLine("Az elem nem léteizk");
        }
    }

    public static int Osszegzes(int[] array)
    {
        int sum = 0;
        foreach (var elem in array)
        {
            sum += elem;
        }
        return sum;
    }

    public static bool Eldontes(int[] array, int keresett)
    {
        foreach (var elem in array)
        {
            if (elem == keresett)
            {
                return true;
            }
        }
        return false;
    }   

    public static int Kivalasztas(int[] array, int keresett)
    {
        foreach (var elem in array)
        {
            if (elem == keresett)
            {
                return elem;
            }
        }
        throw new Exception("Az elem nem léteizk!");
    }

    public static int LinearisKereses(int[] array, int keresett)
    {
        for (int i = 0; i < array.Length; i++)
        {
            if (array[i] == keresett)
            {
                return i;
            }
        }
        return -1;
    }
}
